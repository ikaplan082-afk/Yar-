"use strict";

/*
  STREET RACING TÜRKİYE - AŞAMA 1
  Tek dosyalık MVP:
  - Canvas tabanlı pseudo-3D yol
  - Oyuncu aracı
  - Yumuşak takip kamerası
  - Mobil / klavye kontrolleri
  - Hızlanma, fren, direksiyon
  - Nitro
  - Basit şehir dekorasyonu
  - Trafik benzeri araçlar
  - Çarpışma
  - localStorage temel kayıt
*/

const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d", {alpha:false});
let W=0,H=0,DPR=1;

function resize(){
  DPR=Math.min(window.devicePixelRatio||1,2);
  W=window.innerWidth; H=window.innerHeight;
  canvas.width=Math.floor(W*DPR);
  canvas.height=Math.floor(H*DPR);
  canvas.style.width=W+"px";
  canvas.style.height=H+"px";
  ctx.setTransform(DPR,0,0,DPR,0,0);
}
addEventListener("resize",resize,{passive:true});
addEventListener("orientationchange",resize,{passive:true});
resize();

const $=id=>document.getElementById(id);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;

const SAVE_KEY="srt_stage1_save";
let save={money:0,bestSpeed:0,distance:0};
try{save=Object.assign(save,JSON.parse(localStorage.getItem(SAVE_KEY)||"{}"));}catch(e){}
function persist(){try{localStorage.setItem(SAVE_KEY,JSON.stringify(save));}catch(e){}}

const state={
  running:false, paused:false, time:0,
  speed:0, maxSpeed:245, acceleration:92, braking:150,
  velocityX:0, lateralGrip:8.5, steeringPower:1.35,
  playerX:0, targetX:0, cameraX:0,
  distance:0, nitro:100, shake:0,
  roadOffset:0, spawnTimer:0, skylineSeed:7, wheelSlip:0, driftScore:0
};

const keys={left:false,right:false,gas:false,brake:false,nitro:false};

function setKey(name,val){
  keys[name]=val;
}

function bindHold(id,name){
  const el=$(id);
  const down=e=>{e.preventDefault();el.classList.add("active");setKey(name,true)};
  const up=e=>{e.preventDefault();el.classList.remove("active");setKey(name,false)};
  ["pointerdown","touchstart"].forEach(t=>el.addEventListener(t,down,{passive:false}));
  ["pointerup","pointercancel","pointerleave","touchend"].forEach(t=>el.addEventListener(t,up,{passive:false}));
}
bindHold("leftBtn","left");
bindHold("rightBtn","right");
bindHold("gasBtn","gas");
bindHold("brakeBtn","brake");
bindHold("nitroBtn","nitro");

addEventListener("keydown",e=>{
  if(["ArrowLeft","a","A"].includes(e.key))setKey("left",true);
  if(["ArrowRight","d","D"].includes(e.key))setKey("right",true);
  if(["ArrowUp","w","W"].includes(e.key))setKey("gas",true);
  if(["ArrowDown","s","S"].includes(e.key))setKey("brake",true);
  if(e.key===" "||e.key==="Shift")setKey("nitro",true);
  if(e.key==="Escape")togglePause();
});
addEventListener("keyup",e=>{
  if(["ArrowLeft","a","A"].includes(e.key))setKey("left",false);
  if(["ArrowRight","d","D"].includes(e.key))setKey("right",false);
  if(["ArrowUp","w","W"].includes(e.key))setKey("gas",false);
  if(["ArrowDown","s","S"].includes(e.key))setKey("brake",false);
  if(e.key===" "||e.key==="Shift")setKey("nitro",false);
});

let traffic=[];
function resetTraffic(){
  traffic=[];
  for(let i=0;i<8;i++){
    traffic.push({
      z:0.15+i*0.11+Math.random()*.07,
      lane:(Math.random()*2-1)*.72,
      speed:.34+Math.random()*.34,
      color:["#dfe6ed","#e84b4b","#f0b429","#5c8cff","#50d890"][i%5],
      width:.075+Math.random()*.025
    });
  }
}

function startGame(){
  state.running=true;state.paused=false;state.time=0;state.speed=0;
  state.playerX=0;state.targetX=0;state.cameraX=0;state.distance=0;
  state.nitro=100;state.shake=0;state.roadOffset=0;
  resetTraffic();
  $("menu").classList.remove("show");
  $("hint").style.opacity="1";
  setTimeout(()=>$("hint").style.opacity="0",4200);
}

function togglePause(){
  if(!state.running)return;
  state.paused=!state.paused;
  $("menu").classList.toggle("show",state.paused);
  if(state.paused){
    $("startBtn").textContent="DEVAM ET";
    $("resetBtn").textContent="YARIŞTAN ÇIK";
  }else{
    $("startBtn").textContent="YARIŞA BAŞLA";
    $("resetBtn").textContent="İLERLEMEYİ SIFIRLA";
  }
}

$("startBtn").addEventListener("click",()=>{
  if(state.paused){state.paused=false;$("menu").classList.remove("show");}
  else startGame();
});
$("pauseBtn").addEventListener("click",togglePause);

$("resetBtn").addEventListener("click",()=>{
  if(state.paused){
    state.running=false;state.paused=false;
    $("menu").classList.remove("show");
    $("startBtn").textContent="YARIŞA BAŞLA";
    $("resetBtn").textContent="İLERLEMEYİ SIFIRLA";
    return;
  }
  save={money:0,bestSpeed:0,distance:0};persist();
});

function roadWidthAt(y){
  const horizon=H*.39;
  const p=clamp((y-horizon)/(H-horizon),0,1);
  return lerp(W*.06,W*.94,p);
}
function roadCenterAt(y){
  const horizon=H*.39;
  const p=clamp((y-horizon)/(H-horizon),0,1);
  return W/2 + Math.sin(state.roadOffset*.0007 + p*3.2)*W*.06*p;
}
function perspectiveY(z){
  const horizon=H*.39;
  return horizon + Math.pow(clamp(z,0,1),1.65)*(H-horizon);
}
function projectLane(lane,z){
  const y=perspectiveY(z), rw=roadWidthAt(y);
  return roadCenterAt(y)+lane*rw*.42;
}

function drawSky(){
  const g=ctx.createLinearGradient(0,0,0,H*.48);
  g.addColorStop(0,"#070b18");g.addColorStop(.55,"#132044");g.addColorStop(1,"#3b3a58");
  ctx.fillStyle=g;ctx.fillRect(0,0,W,H);

  // moon
  ctx.beginPath();ctx.arc(W*.78,H*.16,Math.min(W,H)*.055,0,Math.PI*2);
  ctx.fillStyle="rgba(255,255,235,.92)";ctx.fill();

  // skyline
  const base=H*.39;
  for(let i=0;i<24;i++){
    const x=(i/24)*W;
    const seed=(i*83+state.skylineSeed)%100;
    const bw=W*(.025+.025*(seed%3));
    const bh=H*(.045+.09*((seed*7)%10)/10);
    ctx.fillStyle=i%3===0?"#101727":"#0c1220";
    ctx.fillRect(x,base-bh,bw,bh);
    ctx.fillStyle="rgba(255,214,94,.35)";
    for(let wy=base-bh+8;wy<base-8;wy+=12){
      if(((Math.floor(wy)+i)%4)<2)ctx.fillRect(x+bw*.25,wy,3,5);
    }
  }
}

function drawRoad(){
  const horizon=H*.39;
  ctx.fillStyle="#171a1f";ctx.fillRect(0,horizon,W,H-horizon);

  // roadside grass/concrete
  ctx.fillStyle="#242c2a";
  ctx.beginPath();ctx.moveTo(0,horizon);ctx.lineTo(W*.47,horizon);ctx.lineTo(W*.06,H);ctx.lineTo(0,H);ctx.fill();
  ctx.beginPath();ctx.moveTo(W*.53,horizon);ctx.lineTo(W,horizon);ctx.lineTo(W,H);ctx.lineTo(W*.94,H);ctx.fill();

  // road trapezoid
  const topW=W*.06,bottomW=W*.94,c=W/2;
  ctx.fillStyle="#25282d";
  ctx.beginPath();ctx.moveTo(c-topW/2,horizon);ctx.lineTo(c+topW/2,horizon);ctx.lineTo(c+bottomW/2,H);ctx.lineTo(c-bottomW/2,H);ctx.closePath();ctx.fill();

  // edge lines
  ctx.lineWidth=3;
  ctx.strokeStyle="rgba(255,255,255,.75)";
  ctx.beginPath();ctx.moveTo(c-topW/2,horizon);ctx.lineTo(c-bottomW/2,H);ctx.stroke();
  ctx.beginPath();ctx.moveTo(c+topW/2,horizon);ctx.lineTo(c+bottomW/2,H);ctx.stroke();

  // lane markings with perspective
  for(let lane=-.5;lane<=.5;lane+=1){
    for(let i=0;i<14;i++){
      let z=((i/14)+(state.roadOffset*.002))%1;
      let z2=Math.min(z+.045,1);
      let y1=perspectiveY(z),y2=perspectiveY(z2);
      let x1=projectLane(lane*1.8,z),x2=projectLane(lane*1.8,z2);
      ctx.strokeStyle="rgba(255,255,255,.68)";
      ctx.lineWidth=lerp(1,7,z);
      ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();
    }
  }

  // street lights
  for(let i=0;i<9;i++){
    let z=((i/9)+(state.roadOffset*.0014))%1;
    let y=perspectiveY(z), rw=roadWidthAt(y), c2=roadCenterAt(y);
    for(const side of [-1,1]){
      const x=c2+side*(rw*.62);
      const h=lerp(10,80,z);
      ctx.strokeStyle="rgba(190,200,220,.7)";
      ctx.lineWidth=lerp(.6,2.5,z);
      ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x,y-h);ctx.lineTo(x-side*h*.18,y-h);ctx.stroke();
      ctx.beginPath();ctx.arc(x-side*h*.18,y-h,lerp(1,5,z),0,Math.PI*2);
      ctx.fillStyle="rgba(255,225,145,.8)";ctx.fill();
    }
  }
}

function drawTrafficCar(t){
  const z=t.z;
  if(z<.02||z>1.05)return;
  const y=perspectiveY(z);
  const x=projectLane(t.lane,z);
  const s=lerp(7,72,z);
  const w=s*(1.05+t.width);
  const h=s*1.55;

  ctx.save();
  ctx.translate(x,y-h*.5);
  ctx.fillStyle="rgba(0,0,0,.28)";
  ctx.beginPath();ctx.ellipse(0,h*.52,w*.72,h*.16,0,0,Math.PI*2);ctx.fill();

  const body=ctx.createLinearGradient(-w/2,0,w/2,0);
  body.addColorStop(0,"#20242a");body.addColorStop(.18,t.color);body.addColorStop(.82,t.color);body.addColorStop(1,"#171a20");
  ctx.fillStyle=body;
  ctx.beginPath();
  ctx.roundRect(-w/2,0,w,h*.72,w*.16);ctx.fill();

  ctx.fillStyle="#10151c";
  ctx.beginPath();ctx.roundRect(-w*.32,h*.1,w*.64,h*.24,w*.08);ctx.fill();

  ctx.fillStyle="#f6f1dc";
  ctx.fillRect(-w*.36,h*.56,w*.15,h*.09);ctx.fillRect(w*.21,h*.56,w*.15,h*.09);
  ctx.restore();
}

function drawPlayer(){
  const x=W/2 + state.cameraX;
  const y=H*.84;
  const w=Math.min(W*.19,150),h=w*1.58;

  ctx.save();
  ctx.translate(x,y);

  if(state.shake>0){
    ctx.translate((Math.random()-.5)*state.shake,(Math.random()-.5)*state.shake);
  }

  // Visual lean from steering / lateral slip.
  ctx.rotate(clamp(state.velocityX*0.12,-0.055,0.055));

  // shadow
  ctx.fillStyle="rgba(0,0,0,.45)";
  ctx.beginPath();ctx.ellipse(0,h*.38,w*.7,h*.16,0,0,Math.PI*2);ctx.fill();

  // nitro flames
  if(keys.nitro && state.nitro>0 && state.speed>70){
    const flame=ctx.createLinearGradient(0,h*.48,0,h);
    flame.addColorStop(0,"rgba(0,220,255,.95)");
    flame.addColorStop(1,"rgba(120,80,255,0)");
    ctx.fillStyle=flame;
    ctx.beginPath();ctx.moveTo(-w*.28,h*.35);ctx.lineTo(-w*.08,h*.95);ctx.lineTo(0,h*.5);ctx.lineTo(w*.08,h*.95);ctx.lineTo(w*.28,h*.35);ctx.closePath();ctx.fill();
  }

  // wheels
  ctx.fillStyle="#080a0e";
  ctx.fillRect(-w*.53,h*.02,w*.16,h*.5);
  ctx.fillRect(w*.37,h*.02,w*.16,h*.5);

  // body
  const body=ctx.createLinearGradient(-w/2,0,w/2,0);
  body.addColorStop(0,"#171b23");
  body.addColorStop(.2,"#12b9df");
  body.addColorStop(.5,"#6be4ff");
  body.addColorStop(.8,"#0d91bb");
  body.addColorStop(1,"#10151d");
  ctx.fillStyle=body;
  ctx.beginPath();
  ctx.moveTo(-w*.43,h*.43);
  ctx.lineTo(-w*.38,h*.12);
  ctx.quadraticCurveTo(-w*.28,-h*.02,0,-h*.04);
  ctx.quadraticCurveTo(w*.28,-h*.02,w*.38,h*.12);
  ctx.lineTo(w*.43,h*.43);
  ctx.quadraticCurveTo(w*.35,h*.58,0,h*.62);
  ctx.quadraticCurveTo(-w*.35,h*.58,-w*.43,h*.43);
  ctx.closePath();ctx.fill();

  // windshield
  ctx.fillStyle="#0a1720";
  ctx.beginPath();
  ctx.moveTo(-w*.27,h*.1);ctx.quadraticCurveTo(0,-h*.01,w*.27,h*.1);
  ctx.lineTo(w*.21,h*.25);ctx.lineTo(-w*.21,h*.25);ctx.closePath();ctx.fill();

  // headlights
  ctx.fillStyle="#eaffff";
  ctx.shadowBlur=18;ctx.shadowColor="#bffaff";
  ctx.fillRect(-w*.34,h*.3,w*.17,h*.06);
  ctx.fillRect(w*.17,h*.3,w*.17,h*.06);
  ctx.shadowBlur=0;

  // center stripe
  ctx.fillStyle="rgba(255,255,255,.35)";
  ctx.fillRect(-w*.025,h*.02,w*.05,h*.47);

  ctx.restore();
}

function update(dt){
  if(!state.running||state.paused)return;
  state.time += dt;

  const steer=(keys.right?1:0)-(keys.left?1:0);
  const gas=keys.gas?1:0;
  const brake=keys.brake?1:0;
  const speed01=clamp(state.speed/(state.maxSpeed+1),0,1);

  // Daha doğal arcade sürüş: gaz + motor freni + güçlü fren.
  const engineAccel=state.acceleration*(1-speed01*0.72);
  if(gas) state.speed += engineAccel*dt;
  else state.speed -= (12+speed01*17)*dt;
  if(brake) state.speed -= state.braking*(0.55+speed01*.45)*dt;

  const usingNitro=keys.nitro && state.nitro>0 && state.speed>35;
  if(usingNitro){
    state.speed += 155*(1-speed01*.35)*dt;
    state.nitro -= 30*dt;
    state.shake=Math.max(state.shake,2.2);
  }else{
    state.nitro=Math.min(100,state.nitro+7.5*dt);
  }
  state.speed=clamp(state.speed,0,state.maxSpeed+(usingNitro?65:0));

  // Direksiyon artık ani konum değişimi yerine yanal ivme/atalet kullanıyor.
  const steerAuthority=0.45+speed01*.95;
  const desiredLateral=steer*state.steeringPower*steerAuthority*(0.45+state.speed/120);
  state.velocityX=lerp(state.velocityX,desiredLateral,1-Math.pow(.001,state.lateralGrip*dt));
  state.wheelSlip=clamp(Math.abs(state.velocityX)*.42+Math.abs(steer)*speed01*.16,0,1);

  state.playerX += state.velocityX*dt;
  state.playerX=clamp(state.playerX,-.92,.92);

  if(!steer) state.playerX=lerp(state.playerX,0,1-Math.pow(.0005,dt));
  state.targetX=state.playerX;
  state.cameraX=lerp(state.cameraX,state.playerX*W*.19,1-Math.pow(.00001,dt));

  state.roadOffset+=state.speed*dt;
  state.distance+=state.speed*dt/3600;
  save.distance=Math.max(save.distance,state.distance);
  save.bestSpeed=Math.max(save.bestSpeed,state.speed);

  if(state.wheelSlip>.16 && state.speed>70 && Math.abs(steer)>0)
    state.driftScore+=state.wheelSlip*state.speed*dt*.22;

  state.shake=Math.max(0,state.shake-18*dt);

  for(const t of traffic){
    const relative=(state.speed/245)*.48+t.speed*.08;
    t.z-=relative*dt;
    t.lane+=Math.sin(state.time*(.5+t.speed)+t.z*4)*.008*dt;
    t.lane=clamp(t.lane,-.72,.72);
    if(t.z<-.05){
      t.z=1.03+Math.random()*.2;
      t.lane=(Math.random()*2-1)*.72;
      t.speed=.3+Math.random()*.4;
    }
  }

  // Çarpışma alanı biraz daha hassas ve hızla orantılı.
  for(const t of traffic){
    if(t.z>.80 && t.z<.98 && Math.abs(t.lane-state.playerX)<.19){
      state.speed*=.46;
      state.velocityX+=(state.playerX<t.lane?-1:1)*.32;
      state.shake=10;
      t.z=.30;
      t.lane=clamp(t.lane+(Math.random()-.5)*.45,-.8,.8);
    }
  }

  $("speed").textContent=Math.round(state.speed);
  $("best").textContent=Math.round(save.bestSpeed)+" KM/H";
  $("distance").textContent=state.distance.toFixed(1)+" KM";
  $("nitroBar").style.width=state.nitro+"%";
  $("roadProgress").style.width=(Math.min(state.distance/10,1)*100)+"%";
  $("gear").textContent="VİTES "+Math.max(1,Math.min(6,Math.floor(state.speed/42)+1));
}

function render(){
  ctx.clearRect(0,0,W,H);
  drawSky();
  drawRoad();

  // distant traffic first
  traffic.slice().sort((a,b)=>a.z-b.z).forEach(drawTrafficCar);

  drawPlayer();

  if(state.speed>155){
    ctx.fillStyle="rgba(255,255,255,.07)";
    for(let i=0;i<12;i++){
      const x=Math.random()*W,y=H*.45+Math.random()*H*.45;
      ctx.fillRect(x,y,1+Math.random()*2,20+Math.random()*55);
    }
  }

  if(state.paused){
    ctx.fillStyle="rgba(0,0,0,.18)";
    ctx.fillRect(0,0,W,H);
  }
}

let last=performance.now();
function loop(now){
  const dt=Math.min((now-last)/1000,.033);
  last=now;
  update(dt);
  render();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

resetTraffic();